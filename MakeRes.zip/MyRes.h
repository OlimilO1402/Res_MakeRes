//Konstante f�r Manifestdatei
#define RT_MANIFEST     24
